def check_prime(n):
    n = int(n)
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    i=5
    while i*i <= n :
      if n % i == 0 or n % (i+2) == 0:
       return False
      i += 6
    return True

def checkRprime(n):
    s = str(n)
    for i in range(len(s)):
        rotation = int(s[i:] + s[:i])
        if not check_prime(rotation):
            return False
    return True

numb =input(" Enter the number to check for rotational prime ")
if checkRprime(numb):
  print(f"{numb} is a Rotational prime.")
else:
   print(f"{numb} is not a Rotational prime.")