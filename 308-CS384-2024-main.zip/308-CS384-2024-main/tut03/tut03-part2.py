def permutation_func(s, strt, end):
    if strt == end:
        print("".join(s))
    else:
        for i in range(strt, end + 1):
            s[strt], s[i] = s[i], s[strt]
            permutation_func(s, strt + 1, end)
            s[strt], s[i] = s[i], s[strt]


string = input("Enter a string: ")
if string:
    s = list(string)
    n = len(s)
    print(f"Permutations of '{string}':")
    permutation_func(s, 0, n - 1)
else:
    print("No permutations for empty string.")