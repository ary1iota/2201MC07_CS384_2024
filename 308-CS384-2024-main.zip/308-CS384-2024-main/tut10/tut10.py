import streamlit as st
import pandas as pd
from io import BytesIO

# Add custom CSS to style the app
st.markdown("""
    <style>
        .title {
            font-size: 36px;
            font-weight: bold;
            color: #4CAF50;
        }
        .description {
            font-size: 18px;
            color: #555;
        }
        .upload-section {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #ddd;
        }
        .download-button {
            background-color: #4CAF50;
            color: white;
            padding: 12px 24px;
            font-size: 16px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
        }
        .download-button:hover {
            background-color: #45a049;
        }
    </style>
""", unsafe_allow_html=True)

# Function to process the uploaded file
def process_file(file):
    # Read the uploaded file into a DataFrame
    df = pd.read_excel(file)

    # Get number of exams, max marks row, weightage row, and student details
    number_of_exams = len(df.columns) - 2
    max_marks_row = df.iloc[0]
    weightage_row = df.iloc[1]
    student_df = df.iloc[2:].copy().reset_index(drop=True)
    student_df['Grand Total'] = 0

    # Calculate Grand Total for each student
    number_of_students = len(student_df)
    for i in range(number_of_students):
        val = 0
        for j in range(number_of_exams):
            val += student_df.iloc[i, j + 2] / max_marks_row[j + 2] * weightage_row[j + 2]
        student_df.at[i, 'Grand Total'] = val
    student_df = student_df.sort_values(by='Grand Total', ascending=False).reset_index(drop=True)

    # Define grade cutoffs
    grade_cutoffs = {
        'AA': int(number_of_students * 0.05),
        'AB': int(number_of_students * 0.15),
        'BB': int(number_of_students * 0.25),
        'BC': int(number_of_students * 0.30),
        'CC': int(number_of_students * 0.15),
        'CD': int(number_of_students * 0.05)
    }
    remaining = number_of_students - sum(grade_cutoffs.values())

    # Assign grades
    grades = (
        ['AA'] * grade_cutoffs['AA'] +
        ['AB'] * grade_cutoffs['AB'] +
        ['BB'] * grade_cutoffs['BB'] +
        ['BC'] * grade_cutoffs['BC'] +
        ['CC'] * grade_cutoffs['CC'] +
        ['CD'] * grade_cutoffs['CD'] +
        ['DD'] * remaining
    )
    student_df['Grade'] = grades

    # Sort by Roll number for output_roll
    sorted_roll = student_df.sort_values(by='Roll', ascending=True)

    # Convert the combined DataFrames into one Excel file with multiple sheets
    output_combined = BytesIO()
    with pd.ExcelWriter(output_combined, engine='openpyxl') as writer:
        student_df.to_excel(writer, sheet_name='Sorted by Grades', index=False)
        sorted_roll.to_excel(writer, sheet_name='Sorted by Roll', index=False)
    output_combined.seek(0)

    return output_combined

# Streamlit app layout and functionality
st.markdown("<div class='title'>LAB-10<br>Student Grading System</div>", unsafe_allow_html=True)

st.markdown("""
    <div class='description'>
        Upload an Excel file with student scores. The website will process the data and calculate the total for each student
        assigning grades according to predefined cutoffs. 
    </div>
""", unsafe_allow_html=True)


# Improved File Upload Section
with st.expander("📁 Upload Student Score File"):
    st.markdown("<div class='upload-section'>", unsafe_allow_html=True)
    uploaded_file = st.file_uploader("Choose an Excel file", type="xlsx")
    st.markdown("</div>", unsafe_allow_html=True)

if uploaded_file is not None:
    # Process the uploaded file and generate the combined output
    output_combined = process_file(uploaded_file)

    # Provide a download link for the combined Excel file
    st.markdown("<div class='download-button'>", unsafe_allow_html=True)
    st.download_button(
        label="Download Processed Grades",
        data=output_combined,
        file_name="combined_output.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    st.markdown("</div>", unsafe_allow_html=True)
