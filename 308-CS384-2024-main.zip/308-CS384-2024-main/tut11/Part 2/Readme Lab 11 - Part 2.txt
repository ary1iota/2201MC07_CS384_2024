Assignment 11 - Scaled Marks CS384 Part B.avi

Download Video 
http://10.12.10.43:8000/1731157416226_7031941

or Watch here 
https://youtu.be/wPBR3Y9g8GE


