import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import mplfinance as mpf
import numpy as np
from tkinter import Tk, filedialog

# File upload function for VS Code
def upload_file():
    root = Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    file_path = filedialog.askopenfilename(title="Select a CSV File", filetypes=[("CSV Files", "*.csv")])
    return file_path


print("Please select the stock data file (CSV format).")
file_name = upload_file()

# Loading the dataset from the uploaded file
if not file_name:
    print("No file selected. Exiting program.")
    exit()

stkDATA = pd.read_csv(file_name)

stkDATA['Date'] = pd.to_datetime(stkDATA['Date'])
# Display the first 10 rows of the dataset
print("First 10 rows of the dataset:")
print(stkDATA.head(10))
# Check and handle missing values
blankValues = stkDATA.isnull().sum()
print(f"\nMissing values before cleaning:\n{blankValues}")
stkDATAClean = stkDATA.dropna()
blankValuesClean = stkDATAClean.isnull().sum()
print(f"\nMissing values after cleaning:\n{blankValuesClean}")


# 2. Data Visualization
# Plot the closing price over time
plt.figure(figsize=(10, 6))
plt.plot(stkDATAClean['Date'], stkDATAClean['Close'], label='Close Price', color='blue')
plt.title('Closing Price Over Time')
plt.xlabel('Date')
plt.ylabel('Close Price')
plt.xticks(rotation=45)
plt.legend()
plt.show()

# Plot candlestick chart using mplfinance
stkDATAClean.set_index('Date', inplace=True)
mpf.plot(stkDATAClean, type='candle', style='charles', volume=True, title='Candlestick Chart')

# 3. Statistical Analysis
# Calculate daily return percentage
stkDATAClean['Daily Return (%)'] = ((stkDATAClean['Close'] - stkDATAClean['Open']) / stkDATAClean['Open']) * 100
# Calculate average and median of daily returns
AvgDailyReturn = stkDATAClean['Daily Return (%)'].mean()
MedianDailyReturn = stkDATAClean['Daily Return (%)'].median()
print(f"\nAverage Daily Return: {AvgDailyReturn:.2f}%")
print(f"Median Daily Return: {MedianDailyReturn:.2f}%")
# Calculate standard deviation of the closing prices
stdClose = stkDATAClean['Close'].std()
print(f"\nStandard Deviation of Closing Prices: {stdClose:.2f}")

# 4. Moving Averages
# Calculate 50-day and 200-day moving averages
stkDATAClean['50-day MA'] = stkDATAClean['Close'].rolling(window=50).mean()
stkDATAClean['200-day MA'] = stkDATAClean['Close'].rolling(window=200).mean()
# Plot moving averages
plt.figure(figsize=(10, 6))
plt.plot(stkDATAClean.index, stkDATAClean['Close'], label='Close Price', color='blue')
plt.plot(stkDATAClean.index, stkDATAClean['50-day MA'], label='50-day MA', color='orange')
plt.plot(stkDATAClean.index, stkDATAClean['200-day MA'], label='200-day MA', color='green')
plt.title('50-day and 200-day Moving Averages')
plt.xlabel('Date')
plt.ylabel('Price')
plt.legend()
plt.xticks(rotation=45)
plt.show()

# 5. Volatility Analysis
# Calculate and plot the rolling standard deviation (volatility) with a 30-day window
stkDATAClean['Volatility (30-day)'] = stkDATAClean['Close'].rolling(window=30).std()
plt.figure(figsize=(10, 6))
plt.plot(stkDATAClean.index, stkDATAClean['Volatility (30-day)'], label='30-day Volatility', color='red')
plt.title('30-day Rolling Volatility')
plt.xlabel('Date')
plt.ylabel('Volatility')
plt.legend()
plt.xticks(rotation=45)
plt.show()

# 6. Trend Analysis (Bullish/Bearish based on moving averages)
# Bullish when 50-day MA is greater than 200-day MA, otherwise bearish
stkDATAClean['Trend'] = np.where(stkDATAClean['50-day MA'] > stkDATAClean['200-day MA'], 'Bullish', 'Bearish')
# Plot bullish/bearish trends
plt.figure(figsize=(10, 6))
plt.plot(stkDATAClean.index, stkDATAClean['Close'], label='Close Price', color='yellow')
plt.fill_between(stkDATAClean.index, stkDATAClean['Close'], color='green', where=stkDATAClean['Trend']=='Bullish', alpha=0.2, label='Bullish')
plt.fill_between(stkDATAClean.index, stkDATAClean['Close'], color='red', where=stkDATAClean['Trend']=='Bearish', alpha=0.2, label='Bearish')
plt.title('Bullish and Bearish Trends')
plt.xlabel('Date')
plt.ylabel('Close Price')
plt.legend()
plt.xticks(rotation=45)
plt.show()
