def passchecker(passesList, crteriaNums):
    specChar = {'!', '@', '#'}
    results = []
    def validate_password(password):
     if len(password) < 8:
        return "Invalid password. Less than 8 Characters."       
     upperCond = False
     lowerCond = False
     digitCond = False
     specialChars = set()
     for char in password:
        if char.isupper():
            upperCond = True
        elif char.islower():
            lowerCond = True
        elif char.isdigit():
            digitCond = True
        else:
            specialChars.add(char)
        if upperCond and lowerCond and digitCond and (not crteriaNums or '4' not in crteriaNums):
            break
     errors = []
     if '1' in crteriaNums and not upperCond:
        errors.append("Uppercase letters missing")
     if '2' in crteriaNums and not lowerCond:
        errors.append("Lowercase letters missing")
     if '3' in crteriaNums and not digitCond:
        errors.append("Numbers missing")
     if '4' in crteriaNums:
        if not specialChars:
            errors.append("Special characters missing")
        elif any(char not in specChar for char in specialChars):
            errors.append(f"Invalid special characters: {', '.join(c for c in specialChars if c not in specChar)}")
     if errors:
        return f"Invalid password. {', '.join(errors)}"
     return "Valid password."
    for password in passesList:
        result = validate_password(password)
        results.append(result)
    return results


passesList = input("Enter passwords separated by commas: ").split(',')
print("Select criteria to validate passwords:")
print("1. Uppercase letters (A-Z)")
print("2. Lowercase letters (a-z)")
print("3. Numbers (0-9)")
print("4. Special characters (!, @, #)")
crteriaNums = input("Enter your selection as comma-separated numbers: ").split(',')
results = passchecker(passesList, crteriaNums)
for i, password in enumerate(passesList):
    print(f"Password: {password.strip()} -> {results[i]}")
