import os

def passchecker(passesList, crteriaNums):
    specChar = {'!', '@', '#'}
    results = []
    def validate_password(password):
     if len(password) < 8:
        return "Invalid password. Less than 8 Characters."       
     upperCond = False
     lowerCond = False
     digitCond = False
     specialChars = set()
     for char in password:
        if char.isupper():
            upperCond = True
        elif char.islower():
            lowerCond = True
        elif char.isdigit():
            digitCond = True
        else:
            specialChars.add(char)
        if upperCond and lowerCond and digitCond and (not crteriaNums or '4' not in crteriaNums):
            break
     errors = []
     if '1' in crteriaNums and not upperCond:
        errors.append("Uppercase letters missing")
     if '2' in crteriaNums and not lowerCond:
        errors.append("Lowercase letters missing")
     if '3' in crteriaNums and not digitCond:
        errors.append("Numbers missing")
     if '4' in crteriaNums:
        if not specialChars:
            errors.append("Special characters missing")
        elif any(char not in specChar for char in specialChars):
            errors.append(f"Invalid special characters: {', '.join(c for c in specialChars if c not in specChar)}")
     if errors:
        return f"Invalid password. {', '.join(errors)}"
     return "Valid password."
    for password in passesList:
        result = validate_password(password)
        results.append(result)
    return results

def validPassFROMFile():
    print("Enter criteria numbers you want to check:")
    print("1. Uppercase letters")
    print("2. Lowercase letters")
    print("3. Numbers")
    print("4. Special characters (!, @, #)")

    crteriaNums = input("Enter your selection as comma-separated numbers: ").split(',')
    
    script_dir = os.getcwd()  
    file_path = os.path.join(script_dir, 'input.txt')

    try:
        with open(file_path, 'r') as file:
            passesList = []
            for password in file:
                password = password.strip()
                passesList.append(password)
            results = passchecker(passesList, crteriaNums)
            for i, password in enumerate(passesList):
             print(f"Password: {password.strip()} -> {results[i]}")    
        
    except FileNotFoundError:
        print(f" The file '{file_path}' does not exist. Please check the file path.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# Programmatic creation of the input.txt file for testing
def create_input_file():
    script_dir = os.getcwd()  
    file_path = os.path.join(script_dir, 'input.txt')

    passwords = [
        "abc12345",
        "abc",
        "123456789",
        "abcdefg$",
        "abcdefgABHD!@313",
        "abcdefgABHD$$!@313"
    ]
    with open(file_path, 'w') as file:
        file.write("\n".join(passwords))

if __name__ == "__main__":
# Create the input.txt file (only needed if file doesn't exist)
    create_input_file()
    validPassFROMFile()
