def checkBalanced(s):
    parenthList = []
    parenthPair = {')': '(', '}': '{', ']': '['}


    for char in s:
        if char in '({[':
            parenthList.append(char)
        elif char in ')}]':
            if not parenthList or parenthList.pop() != parenthPair[char]:
                return "The input string is NOT balanced."
            
    return "The input string is balanced." if not parenthList else "The input string is NOT balanced."

data = input("Enter a string with parentheses to check if it's balanced: ")
print(checkBalanced(data))
