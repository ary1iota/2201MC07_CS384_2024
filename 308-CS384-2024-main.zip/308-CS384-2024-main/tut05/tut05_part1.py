def uniqueTriplets(nums):
    nums.sort()
    triplets = []
    for i in range(len(nums) - 2):
        if i > 0 and nums[i] == nums[i - 1]:
            continue        
        temp = -nums[i]
        l, r = i + 1, len(nums) - 1
        while l < r:
            currSum = nums[l] + nums[r]
            if currSum == temp:
                triplets.append([nums[i], nums[l], nums[r]])
                while l < r and nums[l] == nums[l + 1]:
                    l += 1
                while l < r and nums[r] == nums[r - 1]:
                    r -= 1
                l += 1
                r -= 1
            elif currSum < temp:
                l += 1
            else:
                r -= 1
    return triplets


numbers = input("Enter numbers separated by commas: ")
nums = list(map(int, numbers.split(',')))
ans = uniqueTriplets(nums)
if ans:
    print("\nUnique triplets that sum to zero:")
    for triplet in ans:
        print(triplet)
else:
    print("\nNo triplets found that sum to zero.")
