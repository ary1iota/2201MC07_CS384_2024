from collections import defaultdict, Counter

def anagramFunc(words):
    anagramDict = defaultdict(list)
    grpFreq = {}
    maxFreq = 0
    maxGrp = None
    for word in words:
        srtKey = tuple(sorted(word))
        anagramDict[srtKey].append(word)

        if srtKey not in grpFreq:
            grpFreq[srtKey] = Counter(word) 
        else:
            grpFreq[srtKey].update(word) 

        totalFreq = sum(grpFreq[srtKey].values())
        if totalFreq > maxFreq:
            maxFreq = totalFreq
            maxGrp = srtKey

    return dict(anagramDict), grpFreq, maxGrp, maxFreq

def main():
    words = input("Enter words separated by spaces: ").split()    
    anagramGroup, freq, maxGrp, maxFreq = anagramFunc(words)

    print("\nAnagram Dictionary:")
    for key, value in anagramGroup.items():
        print(f"{''.join(key)}: {value}")

    print("\nCharacter frequency:")
    for key, value in freq.items():
        print(f"{''.join(key)}: {dict(value)}")

    print(f"\nHighest Frequency Group: {''.join(maxGrp)} with Total Frequency: {maxFreq}")

if __name__ == "__main__":
    main()