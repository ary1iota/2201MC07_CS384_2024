def addStu(studDict, name):
    name = name.lower()
    if name in studDict:
        print(f"Student {name.capitalize()} already exist")
    else:
        grades = input("Enter grades for three subjects separated by commas: ")
        grades = list(map(int, grades.split(','))) 
        if len(grades) == 3:
            studDict[name] = grades
            print(f"Student {name.capitalize()} is added.")
        else:
            print("Please enter exactly three grades separated by commas.")

def updStu(studDict, name):
    name = name.lower() 
    if name in studDict:
       grades = input("Enter updated grades for three subjects separated by commas: ")
       grades = list(map(int, grades.split(',')))
       if len(grades) == 3:
            studDict[name] = grades
            print(f"Grades for {name.capitalize()} is updated.")
       else:
            print("Please enter exactly three grades separated by commas.")
    else:
        print(f"Student {name.capitalize()} does not exist.")

def calcAVG(studDict):
    return {student: sum(grades) / len(grades) for student, grades in studDict.items()}

def printAVG(studDict):
    averages = calcAVG(studDict)
    for student, avg in averages.items():
        print(f"{student.capitalize()} - Average: {avg:.2f}")

def srtSTU(studDict):
    srtData = []
    for student, grades in studDict.items():
        total = sum(grades)
        srtData.append((student, total))
    
    for i in range(len(srtData)):
        for j in range(i + 1, len(srtData)):
            if srtData[j][1] > srtData[i][1]:
                srtData[i], srtData[j] = srtData[j], srtData[i]
    
    return srtData

def mainfnc():
    students = {}
    while True:     
        choice = input("Enter your choice (1-5): ")
        if choice == '1':
            name = input("Enter student's name: ")
            addStu(students, name)
        elif choice == '2':
            name = input("Enter student's name to update: ")
            updStu(students, name)
        elif choice == '3':
            print("\nAverage grades of students:")
            printAVG(students)
        elif choice == '4':
            print("\nStudents sorted by total grades in descending order:")
            sorted_students = srtSTU(students)
            for student, total in sorted_students:
                print(f"{student.capitalize()} - Total Grade: {total}")
        elif choice == '5':
            print("exit")
            break
        else:
            print("Please select a valid option (1-5).")


print("Choose an option:")
print("1. Add a new student with grades")
print("2. Update grades of an existing student")
print("3. Calculate the average grade of each student and Print all students with their average grades")
print("4. Sort students by their grades in descending order")
print("5. Exit")
        
mainfnc()
