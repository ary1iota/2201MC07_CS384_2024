import tkinter as tk
from tkinter import filedialog
import pandas as pd
from datetime import datetime
from openpyxl import load_workbook
from openpyxl.styles import PatternFill

# Function to upload required files
def select_file(file_types=("All Files", "*.*"), file_message="Select a file"):
    root = tk.Tk()
    root.withdraw()  # Don't show the Tkinter root window
    print(file_message)  # Display message asking which file to upload
    file_path = filedialog.askopenfilename(filetypes=[(file_types[0], file_types[1])])
    return file_path

# Function to check if the timestamp is within the specified class time range
def is_within_time_range(timestamp, start_time, end_time):
    try:
        # Parse the timestamp to extract the time
        time_obj = datetime.strptime(timestamp, "%d/%m/%Y %H:%M:%S").time()
        
        # Parse the start and end times
        start = datetime.strptime(start_time, "%H:%M").time()
        end = datetime.strptime(end_time, "%H:%M").time()
        
        # Check if the time falls within the range
        return start <= time_obj <= end
    except ValueError as e:
        print(f"Error parsing time in timestamp '{timestamp}': {e}")
        return False

# Function to process attendance and generate the output file
def process_attendance_file(input_file_path, student_list_file_path, date_info, output_file_path):
    if input_file_path.endswith('.csv'):
        data = pd.read_csv(input_file_path)
    elif input_file_path.endswith('.xlsx'):
        data = pd.read_excel(input_file_path)
    else:
        raise ValueError("Unsupported file format. Only CSV and Excel files are supported.")
    with open(student_list_file_path, 'r') as f:
        student_list = [line.strip() for line in f.readlines()]
    all_students_df = pd.DataFrame(student_list, columns=['Roll'])
    all_dates = date_info["classes_taken_dates"] + date_info["classes_missed_dates"] + date_info["exams_dates"]

    for date in all_dates:
        all_students_df[date] = 0 
    for index, row in data.iterrows():
        roll = row['Roll']
        timestamp = row['Timestamp']
        date = timestamp.split()[0]

        # Convert date format from 'dd-mm-yyyy' or 'dd/mm/yyyy' to 'dd/mm/yyyy'
        try:
            # Try parsing with both possible formats
            if '-' in date:
                date = datetime.strptime(date, "%d-%m-%Y").strftime("%d/%m/%Y")
            else:
                date = datetime.strptime(date, "%d/%m/%Y").strftime("%d/%m/%Y")
        except ValueError as e:
            print(f"Error parsing date '{date}': {e}")
            continue  # Skip this row if the date is invalid

        if roll in student_list:
            if is_within_time_range(timestamp, date_info["class_timing"][0], date_info["class_timing"][1]):
                if date in all_students_df.columns:
                    all_students_df.loc[all_students_df['Roll'] == roll, date] += 1

    # Add the three new columns
    # 1. Total Attendance: Sum all the attendance counts per student across all dates
    all_students_df['Total Attendance'] = all_students_df[all_dates].sum(axis=1)
    # 2. Days Present: Count the number of days where attendance was marked (count > 0)
    all_students_df['Days Present'] = (all_students_df[all_dates] > 0).sum(axis=1)
    # 3. Total Attendance Allowed: len(classes_taken_dates) * 2
    total_classes = len(date_info["classes_taken_dates"])
    all_students_df['Total Attendance Allowed'] = total_classes * 2
    # 4. Proxy: Track excess attendances for both `classes_taken_dates` and other dates
    all_students_df['Proxy'] = 0  # Initialize Proxy column
    for index, row in all_students_df.iterrows():
        proxy_count = 0
        for date in date_info["classes_taken_dates"]:
            if row[date] > 2:
                proxy_count += (row[date] - 2)
        for date in date_info["classes_missed_dates"] + date_info["exams_dates"]:
            if row[date] > 0:
                proxy_count += row[date]
        all_students_df.at[index, 'Proxy'] = proxy_count

    # Save the result to an Excel file before applying colors
    all_students_df.to_excel(output_file_path, index=False)

    # Load the workbook and select the active worksheet
    workbook = load_workbook(output_file_path)
    worksheet = workbook.active

    # Define the colors
    red_fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
    yellow_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    green_fill = PatternFill(start_color="00FF00", end_color="00FF00", fill_type="solid")

    # Apply colors to the date columns based on attendance count
    for row in range(2, worksheet.max_row + 1):
        for col in range(2, worksheet.max_column - 4):  # Exclude the last four new columns
            count = worksheet.cell(row=row, column=col).value
            if count == 0:
                worksheet.cell(row=row, column=col).fill = red_fill
            elif count == 1:
                worksheet.cell(row=row, column=col).fill = yellow_fill
            elif count == 2:
                worksheet.cell(row=row, column=col).fill = green_fill
    workbook.save(output_file_path)

# Function to parse the dates and class timing information from the text file
def parse_date_info(date_info_file):
    with open(date_info_file, 'r') as file:
        date_info = {}
        lines = file.readlines()
        for line in lines:
            if "classes_taken_dates" in line:
                date_info["classes_taken_dates"] = eval(line.split('=')[1].strip())
            elif "classes_missed_dates" in line:
                date_info["classes_missed_dates"] = eval(line.split('=')[1].strip())
            elif "exams_dates" in line:
                date_info["exams_dates"] = eval(line.split('=')[1].strip())
            elif "class_timing" in line:
                timing = line.split('=')[1].strip().split("#")[0].strip().split("-")
                date_info["class_timing"] = (timing[0].strip(), timing[1].strip())
    return date_info

# Step 1: Let the user select the files with corresponding messages
input_file_path = select_file(("CSV Files", "*.csv") + ("Excel Files", "*.xlsx"), "Please upload the attendance file (CSV or Excel):")
student_list_file_path = select_file(("Text Files", "*.txt"), "Please upload the student list file (Text file):")
date_info_file_path = select_file(("Text Files", "*.txt"), "Please upload the date information file (Text file):")

# Step 2: Parse the date information from the text file
date_info = parse_date_info(date_info_file_path)

# Step 3: Define the output file path
output_file_path = 'output_attendance_by_date.xlsx'

# Step 4: Process the attendance and generate the output file
process_attendance_file(input_file_path, student_list_file_path, date_info, output_file_path)

print(f"Attendance has been processed and saved to {output_file_path}")
