def uSum(n):
    while n >= 10:
        tmp = 0
        while n > 0:
            tmp += n % 10
            n = n // 10
        n = tmp
    return n

number = int(input("Enter an integer: "))
ans = uSum(number)
print(f"The unitry sum of the inputed number is: {ans}")